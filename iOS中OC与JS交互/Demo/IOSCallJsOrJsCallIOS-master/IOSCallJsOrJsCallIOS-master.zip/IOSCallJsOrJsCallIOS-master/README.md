# IOSCallJsOrJsCallIOS
A good demo for iOS call js and js call ios native, using JavaScriptCore after iOS 7.0.

##Swift版Demo
如需讲解，请到微信公众号阅读：<br/>
[Swift版与JS交互实战篇](http://mp.weixin.qq.com/s?__biz=MzIzMzA4NjA5Mw==&mid=214070747&idx=1&sn=57b45fa293d0500365d9a0a4ff74a4e1#rd)

[ObjC版与JS交互实战篇](http://mp.weixin.qq.com/s?__biz=MzIzMzA4NjA5Mw==&mid=214063688&idx=1&sn=903258ec2d3ae431b4d9ee55cb59ed89#rd)

##关注我
请关注微信公众号：iOSDevShares

![image](https://github.com/CoderJackyHuang/IOSCallJsOrJsCallIOS/blob/master/wx.jpg)
